//Bryant Wong
//CSCI 2421 Homework 1

#include "Guess.h"

int main()
{
	//creates a class "gu"
	Guess gu;
	//member function call for StartGuess to run the entire program
	gu.StartGuess();
	return 0;
}